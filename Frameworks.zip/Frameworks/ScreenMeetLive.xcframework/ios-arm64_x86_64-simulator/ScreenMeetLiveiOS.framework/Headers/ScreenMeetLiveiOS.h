//
//  ScreenMeetLiveiOS.h
//  ScreenMeetLiveiOS
//
//  Created by Ross on 25.08.2022.
//

#import <Foundation/Foundation.h>

//! Project version number for ScreenMeetLiveiOS.
FOUNDATION_EXPORT double ScreenMeetLiveiOSVersionNumber;

//! Project version string for ScreenMeetLiveiOS.
FOUNDATION_EXPORT const unsigned char ScreenMeetLiveiOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ScreenMeetLiveiOS/PublicHeader.h>


